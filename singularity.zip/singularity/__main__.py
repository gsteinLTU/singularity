#!/usr/bin/env python

# file: singularity.py
# Copyright (C) 2005 Evil Mr Henry, Phil Bordelon, Brian Reid, MestreLion
# This file is part of Endgame: Singularity.

# Endgame: Singularity is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.

# Endgame: Singularity is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# A full copy of this license is provided in GPL.txt

# This file is the starting file for the game. Run it to start the game.

from singularity import main

if __name__ == "__main__":
    main()
